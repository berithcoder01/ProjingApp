/**
 * pdfService.js
 * Gera o PDF da proposta capturando o DOM do ProposalDocument
 * via html-to-image (PNG de alta resolução) e inserindo no jsPDF.
 * Estratégia idêntica à usada no geestao-main.
 */

export const generatePDF = async (propNum, documentRef) => {
  if (!window.jspdf || !window.htmlToImage) {
    alert('Erro: Bibliotecas de PDF não carregadas. Verifique sua conexão e recarregue a página.');
    console.error('jsPDF or html-to-image not loaded.');
    return;
  }

  const node = documentRef?.current;
  if (!node) {
    alert('Erro: Documento da proposta não encontrado.');
    console.error('ProposalDocument ref not found.');
    return;
  }

  const { jsPDF } = window.jspdf;
  const filename = `Proposta_${propNum.replace(/\//g, '-')}.pdf`;

  try {
    // Aguarda renderização completa
    await new Promise(resolve => setTimeout(resolve, 200));

    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
    const pdfW = pdf.internal.pageSize.getWidth();
    const pdfH = pdf.internal.pageSize.getHeight();

    // Tenta capturar por páginas individuais (.pj-page) para evitar cortes
    const pages = node.querySelectorAll('.pj-page');
    
    if (pages.length > 0) {
      for (let i = 0; i < pages.length; i++) {
        const pageDataUrl = await window.htmlToImage.toJpeg(pages[i], {
          quality: 0.95,
          pixelRatio: 2.0,
          backgroundColor: '#ffffff',
          cacheBust: true,
        });

        const imgProps = pdf.getImageProperties(pageDataUrl);
        const imgH = (imgProps.height * pdfW) / imgProps.width;

        // Se a página for maior que o A4 (ex: texto de faturamento muito longo), fatia em várias
        if (imgH <= pdfH + 2) {
          if (i > 0) pdf.addPage();
          pdf.addImage(pageDataUrl, 'JPEG', 0, 0, pdfW, imgH, undefined, 'FAST');
        } else {
          // Slicing com sobreposição (overlap) para evitar cortar texto ao meio
          // Usamos 98% da altura para garantir que a linha cortada apareça inteira na próxima
          let currentY = 0;
          const sliceH = pdfH * 0.98; 
          
          while (currentY < imgH) {
            if (i > 0 || currentY > 0) pdf.addPage();
            pdf.addImage(pageDataUrl, 'JPEG', 0, -currentY, pdfW, imgH, undefined, 'FAST');
            
            // Se chegamos ao fim, paramos
            if (currentY + pdfH >= imgH) break;
            
            currentY += sliceH;
          }
        }
      }
    } else {
      // Fallback: captura o nó inteiro e fatia (comportamento antigo)
      const dataUrl = await window.htmlToImage.toJpeg(node, {
        quality: 0.9,
        pixelRatio: 2.0,
        backgroundColor: '#ffffff',
      });
      
      const imgProps = pdf.getImageProperties(dataUrl);
      const imgH = (imgProps.height * pdfW) / imgProps.width;

      if (imgH <= pdfH) {
        pdf.addImage(dataUrl, 'JPEG', 0, 0, pdfW, imgH);
      } else {
        let yOffset = 0;
        while (yOffset < imgH) {
          pdf.addImage(dataUrl, 'JPEG', 0, -yOffset, pdfW, imgH, undefined, 'FAST');
          yOffset += pdfH;
          if (yOffset < imgH) pdf.addPage();
        }
      }
    }

    // Usar Blob e <a> para garantir o download com nome e extensão corretos
    const blob = pdf.output('blob');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    
    // Limpeza
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);

    return true;
  } catch (error) {
    alert('Erro ao gerar PDF: ' + error.message);
    console.error('Erro ao gerar PDF:', error);
    return false;
  }
};
