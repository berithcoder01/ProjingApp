import React from 'react';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import Input from '../../../shared/Input';
import Button from '../../../shared/Button';

const StepCondicoes = ({ data, onChange, onNext, onBack }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div>
        <h2 className="text-2xl font-extrabold font-syne mb-2">Condições Comerciais</h2>
        <p className="text-muted text-sm">Defina pagamento, prazo e o modelo de precificação da proposta.</p>
      </div>

      {/* Tipo de Proposta */}
      <div className="bg-surface border-2 border-border p-6 rounded-2xl space-y-4">
        <label className="text-xs font-bold uppercase tracking-wider text-muted">Modelo de Precificação</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button 
            type="button"
            onClick={() => onChange({ ...data, tipoProposta: 'valor_fechado' })}
            className={`p-4 rounded-xl border-2 transition-all text-left ${
              data.tipoProposta === 'valor_fechado' ? 'border-accent bg-accent/10' : 'border-border bg-bg hover:border-accent/30'
            }`}
          >
            <div className={`font-bold text-sm mb-1 ${data.tipoProposta === 'valor_fechado' ? 'text-white' : 'text-muted'}`}>Valor Fechado</div>
            <div className="text-[11px] text-muted">Ideal para projetos com escopo, quantidades e valores finais bem definidos.</div>
          </button>
          <button 
            type="button"
            onClick={() => onChange({ ...data, tipoProposta: 'servico_continuo' })}
            className={`p-4 rounded-xl border-2 transition-all text-left ${
              data.tipoProposta === 'servico_continuo' ? 'border-accent bg-accent/10' : 'border-border bg-bg hover:border-accent/30'
            }`}
          >
            <div className={`font-bold text-sm mb-1 ${data.tipoProposta === 'servico_continuo' ? 'text-white' : 'text-muted'}`}>Serviço Contínuo / Medição</div>
            <div className="text-[11px] text-muted">Ideal para faturamento baseado em medição (ex: horas, metros instalados) após execução.</div>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
        <Input 
          type="number"
          label="Entrada (%)" 
          value={data.entrada} 
          onChange={e => onChange({ ...data, entrada: e.target.value })} 
        />
        <Input 
          type="number"
          label="Prazo pagamento entrada (dias)" 
          value={data.prazoEntrada} 
          onChange={e => onChange({ ...data, prazoEntrada: e.target.value })} 
        />
        <Input 
          type="number"
          label="Medição a cada (dias de avanço)" 
          value={data.medicao} 
          onChange={e => onChange({ ...data, medicao: e.target.value })} 
        />
        <Input 
          type="number"
          label="Pagamento após NF (dias)" 
          value={data.prazoNF} 
          onChange={e => onChange({ ...data, prazoNF: e.target.value })} 
        />
        <Input 
          type="number"
          label="Validade da proposta (dias)" 
          value={data.validade} 
          onChange={e => onChange({ ...data, validade: e.target.value })} 
        />
        <Input 
          label="Prazo de execução" 
          placeholder="Ex.: 45 dias corridos"
          value={data.prazoExec} 
          onChange={e => onChange({ ...data, prazoExec: e.target.value })} 
        />
      </div>

      <div className="space-y-6">
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted">Forma de pagamento (detalhes)</label>
          <textarea 
            rows={3} 
            value={data.formaPagamento} 
            onChange={e => onChange({ ...data, formaPagamento: e.target.value })}
            placeholder="Ex.: Depósito bancário, PIX, boleto..." 
            className="bg-bg border-2 border-border rounded-xl px-4 py-3 text-sm text-white outline-none transition-all focus:border-accent focus:ring-4 focus:ring-accent/15 placeholder:text-muted/50"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted">Observações / Condições especiais</label>
          <textarea 
            rows={4} 
            value={data.obs} 
            onChange={e => onChange({ ...data, obs: e.target.value })}
            placeholder="Ex.: Fator climático é determinante no cumprimento do prazo..." 
            className="bg-bg border-2 border-border rounded-xl px-4 py-3 text-sm text-white outline-none transition-all focus:border-accent focus:ring-4 focus:ring-accent/15 placeholder:text-muted/50"
          />
        </div>
      </div>

      <div className="flex justify-between pt-4">
        <Button variant="ghost" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft size={18} /> Voltar
        </Button>
        <Button onClick={onNext} className="flex items-center gap-2">
          Revisar proposta <ArrowRight size={18} />
        </Button>
      </div>
    </motion.div>
  );
};

export default StepCondicoes;
