import React from 'react';
import { fmt } from '../constants';
import { Phone, Mail, Globe, MapPin, Hash } from 'lucide-react';

// Calcula metros de cabo: (LARGURA×2 + COMPRIMENTO×2) + 5%
const calcMetrosCabo = (largura, comprimento) => {
  const l = parseFloat(largura) || 0;
  const c = parseFloat(comprimento) || 0;
  return Math.ceil((l * 2 + c * 2) * 1.05);
};

const ArmazemDocument = React.forwardRef(({ data, companySettings }, ref) => {
  const calc = data._calculo || {};
  const primaryColor = companySettings?.primaryColor || '#1A5276';
  const textColor = '#333333';
  const mutedColor = '#666666';
  const borderColor = '#CCCCCC';

  const todayDate = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
  const cidade = data.local?.split(',')[0] || 'Marialva';

  // Verifica se temos faturamento direto para decidir a estrutura de páginas
  const temFaturamentoDireto = !!(data.faturamentoDireto && data.condicoesFaturamento);

  return (
    <div
      ref={ref}
      id="armazem-proposal-document"
      style={{
        width: '210mm',
        background: '#f0f0f0',
        display: 'flex',
        flexDirection: 'column',
        gap: '20px'
      }}
    >
      {/* ========== PÁGINA 1: CABEÇALHO + IDENTIFICAÇÃO + DESCRIÇÃO ========== */}
      <div className="pj-page" style={pageStyle}>
        <div style={pageInnerStyle}>
          <Header primaryColor={primaryColor} settings={companySettings} />

          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <h1 style={{ fontSize: '26pt', fontWeight: 'bold', color: '#000', margin: '0', letterSpacing: '2px' }}>PROPOSTA COMERCIAL</h1>
            <div style={{ fontSize: '12pt', color: '#555', fontWeight: 'bold', marginTop: '5px' }}>{data.numeroProposta}</div>
          </div>

          <SectionTitle title="DADOS DA PROPOSTA" color={primaryColor} />
          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '25px' }}>
            <tbody>
              <DataRow label="Cliente:" value={data.cliente} border />
              <DataRow label="Contato:" value={data.contato} border />
              <DataRow label="Local:" value={data.local} border />
              <DataRow label="Objeto:" value={data.objeto || 'Revestimento interno de armazém graneleiro em PEAD'} border />
            </tbody>
          </table>

          <SectionTitle title="DESCRIÇÃO DOS SERVIÇOS" color={primaryColor} />
          <div style={{ marginBottom: '15px' }}>
            <h3 style={{ fontSize: '12pt', fontWeight: 'bold', color: primaryColor, margin: '0 0 8px' }}>
              Item 01.01 — Revestimento de Rampas e Peitos (Armazém Graneleiro)
            </h3>
            <p style={{ fontSize: '10pt', color: textColor, margin: 0, whiteSpace: 'pre-line', textAlign: 'justify', lineHeight: '1.5' }}>
              {data.descricaoServico}
            </p>
          </div>
        </div>
      </div>

      {/* ========== PÁGINA 2: CARACTERÍSTICAS + ESCOPO ========== */}
      <div className="pj-page" style={pageStyle}>
        <div style={pageInnerStyle}>
          {data.caracteristicasMaterial && (
            <div style={{ marginBottom: '30px', padding: '20px', background: '#f8f9fa', border: `1px solid ${borderColor}`, borderRadius: '10px' }}>
              <strong style={{ fontSize: '11pt', color: primaryColor, display: 'block', marginBottom: '10px', textTransform: 'uppercase' }}>Características Técnicas do Material:</strong>
              <p style={{ fontSize: '10pt', color: textColor, margin: 0, whiteSpace: 'pre-line', lineHeight: '1.6' }}>
                {data.caracteristicasMaterial}
              </p>
            </div>
          )}

          <SectionTitle title="ESCOPO E RESPONSABILIDADES" color={primaryColor} />
          <div style={{ marginBottom: '25px' }}>
            <h4 style={{ fontSize: '11pt', fontWeight: 'bold', color: primaryColor, margin: '0 0 10px' }}>Responsabilidades da Contratada</h4>
            <p style={{ fontSize: '10pt', color: textColor, margin: 0, whiteSpace: 'pre-line', lineHeight: '1.5' }}>
              {data.escopoResponsabilidades || '• Mão de obra e materiais\n• Equipamentos e ferramentas\n• EPIs para toda equipe'}
            </p>
          </div>
          
          <div style={{ marginBottom: '25px' }}>
            <h4 style={{ fontSize: '11pt', fontWeight: 'bold', color: primaryColor, margin: '0 0 10px' }}>Itens Inclusos no Fornecimento</h4>
            <p style={{ fontSize: '10pt', color: textColor, margin: 0, whiteSpace: 'pre-line', lineHeight: '1.5' }}>
              {data.itensInclusos}
            </p>
          </div>

          {data.fornecimentoCliente && (
            <div style={{ marginTop: '30px', padding: '15px', borderLeft: `5px solid ${primaryColor}`, background: '#fcfcfc', borderRadius: '0 8px 8px 0' }}>
              <strong style={{ fontSize: '10pt', color: primaryColor, textTransform: 'uppercase' }}>Fornecimento por conta do Cliente:</strong>
              <p style={{ fontSize: '10pt', color: textColor, margin: '8px 0 0 0', lineHeight: '1.4' }}>{data.fornecimentoCliente}</p>
            </div>
          )}
        </div>
      </div>

      {/* ========== PÁGINA 3: GARANTIAS + VALOR + PAGAMENTO ========== */}
      <div className="pj-page" style={pageStyle}>
        <div style={pageInnerStyle}>
          <SectionTitle title="GARANTIAS DO SISTEMA" color={primaryColor} />
          <ul style={{ listStyleType: 'disc', paddingLeft: '25px', marginBottom: '35px' }}>
            <li style={liStyle}><strong>{data.garantiaDefeitos || '5'} anos</strong> contra defeitos de fabricação e instalação da Geomembrana PEAD.</li>
            <li style={liStyle}><strong>{data.garantiaAcidentes || '1'} ano</strong> contra danos acidentais (rasgamento, ruptura e furos).</li>
            <li style={liStyle}><strong>{data.durabilidade || '30'} anos</strong> de durabilidade estimada do material.</li>
            <li style={liStyle}>Vistorias técnicas programadas: {data.vistorias || '1º, 3º e 5º ano'}.</li>
          </ul>

          <SectionTitle title="VALORES DA PROPOSTA" color={primaryColor} />
          <table style={{ width: '100%', borderCollapse: 'collapse', border: `1px solid ${borderColor}`, marginBottom: '35px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <thead>
              <tr style={{ background: primaryColor, color: '#fff' }}>
                <th style={thStyle}>ITEM</th>
                <th style={{ ...thStyle, textAlign: 'left' }}>DESCRIÇÃO DOS SERVIÇOS E MATERIAIS</th>
                <th style={thStyle}>UNID.</th>
                <th style={thStyle}>VALOR TOTAL (R$)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={tdStyle}>01</td>
                <td style={{ ...tdStyle, textAlign: 'left' }}>Geomembrana PEAD (Material, Logística e Tributos)</td>
                <td style={tdStyle}>UN</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 'bold' }}>{fmt(parseFloat(data.valorMaterialManual) || 0)}</td>
              </tr>
              <tr style={{ background: '#f8f9fa' }}>
                <td style={tdStyle}>02</td>
                <td style={{ ...tdStyle, textAlign: 'left' }}>Mão de obra especializada e materiais acessórios de fixação</td>
                <td style={tdStyle}>UN</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 'bold' }}>{fmt(parseFloat(data.valorMaoDeObra) || 0)}</td>
              </tr>
              <tr style={{ background: primaryColor, color: '#fff' }}>
                <td colSpan={3} style={{ padding: '12px 15px', textAlign: 'right', fontWeight: 'bold', fontSize: '12pt' }}>VALOR TOTAL GERAL DA PROPOSTA:</td>
                <td style={{ padding: '12px 15px', textAlign: 'right', fontWeight: 'bold', fontSize: '13pt' }}>{fmt(data.totalGeral || 0)}</td>
              </tr>
            </tbody>
          </table>

          <SectionTitle title="CONDIÇÕES DE PAGAMENTO" color={primaryColor} />
          <ul style={{ listStyleType: 'disc', paddingLeft: '25px', marginBottom: '25px' }}>
            <li style={liStyle}><strong>{data.percentualEntrada || '15'}%</strong> de entrada (mobilização): pagamento em {data.prazoEntrada || '45'} dias.</li>
            <li style={liStyle}><strong>{data.percentualMaterial || '40'}%</strong> na entrega da Geomembrana no canteiro: pagamento em {data.prazoMaterial || '28'} dias.</li>
            <li style={liStyle}><strong>{100 - parseFloat(data.percentualEntrada || 0) - parseFloat(data.percentualMaterial || 0)}%</strong> de saldo final após conclusão: pagamento em {data.prazoSaldo || '28'} dias.</li>
            <li style={liStyle}>Forma de pagamento: {data.formaPagamento || 'depósito bancário'}.</li>
          </ul>
        </div>
      </div>

      {/* ========== PÁGINA 4: CONDIÇÕES DE FATURAMENTO + IMPOSTOS + ENCERRAMENTO ========== */}
      <div className="pj-page" style={pageStyle}>
        <div style={{ ...pageInnerStyle, display: 'flex', flexDirection: 'column' }}>
          {temFaturamentoDireto && (
            <div style={{ marginBottom: '40px' }}>
              <SectionTitle title="CONDIÇÕES DE FATURAMENTO DIRETO" color={primaryColor} />
              <div style={{ padding: '5px 0' }}>
                <p style={{ fontSize: '10pt', color: textColor, margin: 0, whiteSpace: 'pre-line', lineHeight: '1.6', textAlign: 'justify' }}>
                  {data.condicoesFaturamento}
                </p>
              </div>
            </div>
          )}

          <div>
            <SectionTitle title="QUADRO DE IMPOSTOS" color={primaryColor} />
            <table style={{ width: '100%', borderCollapse: 'collapse', border: `1px solid ${borderColor}`, marginBottom: '35px' }}>
              <thead>
                <tr style={{ background: primaryColor, color: '#fff' }}>
                  <th style={thStyle}>CATEGORIA</th>
                  <th style={thStyle}>IMPOSTO</th>
                  <th style={thStyle}>ALÍQUOTA (%)</th>
                </tr>
              </thead>
              <tbody>
                <tr><td style={tdStyle} rowSpan={2}>Serviços</td><td style={tdStyle}>DAS Federal</td><td style={tdStyle}>{data.impostoDAS || '11,20'}%</td></tr>
                <tr><td style={tdStyle}>ISS</td><td style={tdStyle}>{data.impostoISS || '2,79'}%</td></tr>
                <tr><td style={tdStyle} rowSpan={2}>Materiais</td><td style={tdStyle}>Geomembrana IPI</td><td style={tdStyle}>{data.impostoIPI || '15,00'}%</td></tr>
                <tr><td style={tdStyle}>DIFAL</td><td style={tdStyle}>{data.impostoDIFAL || '6,00'}%</td></tr>
              </tbody>
            </table>

            <SectionTitle title="MULTA CONTRATUAL" color={primaryColor} />
            <p style={{ fontSize: '11pt', marginBottom: '30px' }}>
              Multa por atraso na entrega da obra: <strong>{data.multaDiaria || '0,3'}% ao dia</strong>, limitado a {data.multaLimite || '10'}% do valor do contrato.
            </p>

            <SectionTitle title="VALIDADE E PRAZO" color={primaryColor} />
            <div style={{ marginBottom: '30px' }}>
              <p style={{ fontSize: '11pt', marginBottom: '10px' }}>
                Validade: <strong>{data.validadeProposta || '60'} dias</strong> a partir da data de emissão.
              </p>
              <p style={{ fontSize: '11pt', marginBottom: '10px' }}>
                Execução: <strong>{data.prazoExecucao || '45'} dias efetivos</strong> por armazém graneleiro.
              </p>
              {data.obsPrazo && (
                <p style={{ fontSize: '10pt', color: mutedColor, fontStyle: 'italic', textAlign: 'justify', marginTop: '10px' }}>
                  Obs.: {data.obsPrazo}
                </p>
              )}
            </div>
          </div>

          <div style={{ marginTop: 'auto' }}>
            <div style={{ textAlign: 'center', marginTop: '50px' }}>
              <div style={{ fontSize: '11pt', marginBottom: '25px', color: mutedColor }}>{cidade}, PR — {todayDate}</div>
              <div style={{ fontSize: '16pt', fontWeight: 'bold', color: primaryColor, marginBottom: '5px' }}>J. Wilson Santos</div>
              <div style={{ fontSize: '11pt', color: '#555', marginBottom: '35px' }}>(44) 9 9813-9141</div>
              <div style={{ fontSize: '11pt', fontStyle: 'italic', color: mutedColor }}>Somos gratos pela oportunidade de parceria neste projeto.</div>
            </div>

            {/* Rodapé Institucional */}
            <div style={{ textAlign: 'center', marginTop: '40px', paddingTop: '20px', borderTop: `1px solid ${borderColor}` }}>
              <div style={{ fontSize: '15pt', fontWeight: 'bold', color: '#E67E22', marginBottom: '5px', letterSpacing: '1px' }}>PROJING — 15 ANOS DE EXPERIÊNCIA</div>
              <p style={{ fontSize: '10pt', color: mutedColor, margin: 0, lineHeight: '1.4' }}>
                Atuamos desenvolvendo soluções inovadoras para o setor de armazenagem de grãos.<br />
                Desenvolvemos tecnologia para evitar impregnação de grãos em rampas, aplicada em silos, armazéns e moegas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

// ── Estilos Auxiliares ───────────────────────────────────────────────────────

const pageStyle = {
  width: '210mm',
  minHeight: '297mm', 
  padding: '25mm 25mm', // Margem de 25mm (padrão Projing)
  background: '#ffffff',
  boxSizing: 'border-box',
  position: 'relative',
  color: '#333'
};

const pageInnerStyle = {
  width: '100%',
  paddingBottom: '25mm' // Rodapé fixo de 25mm
};

import logoProjing from '../../../../logo.svg';

const Header = ({ primaryColor, settings }) => {
  const cName = (settings?.companyName || 'PROJING').toUpperCase();
  const isProjing = cName === 'PROJING';
  
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '45px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
        <div>
          {isProjing ? (
            <img src={logoProjing} alt="PROJING" style={{ height: '50px', objectFit: 'contain' }} />
          ) : (
            <>
              <div style={{ fontSize: '28pt', fontWeight: '900', color: '#333', letterSpacing: '-1px', lineHeight: '1' }}>
                {cName}
              </div>
              <div style={{ fontSize: '9pt', color: '#666', fontWeight: 'bold', marginTop: '3px', letterSpacing: '1px' }}>SOLUÇÕES EM PEAD</div>
            </>
          )}
        </div>
        <div style={{ width: '3px', height: '50px', background: primaryColor, marginLeft: '5px' }} />
      </div>
      <div style={{ textAlign: 'right', fontSize: '8.5pt', color: '#333', lineHeight: '1.7' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
          {settings?.phone || '(44) 9 9813-9141'} <Phone size={11} color={primaryColor} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
          {settings?.email || 'projingehbengenharia@hotmail.com'} <Mail size={11} color={primaryColor} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
          {settings?.website || 'www.projing.pro'} <Globe size={11} color={primaryColor} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
          CNPJ {settings?.cnpj || '54.348.703/0001-34'} <Hash size={11} color={primaryColor} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
          {settings?.address || 'Rua João Hungari, 575, Marialva PR, CEP 86990-000'} <MapPin size={11} color={primaryColor} />
        </div>
      </div>
    </div>
  );
};

const SectionTitle = ({ title, color }) => (
  <div style={{
    color: color,
    fontWeight: 'bold',
    fontSize: '15pt',
    borderBottom: `3px solid ${color}`,
    paddingBottom: '6px',
    marginTop: '30px',
    marginBottom: '15px',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  }}>{title}</div>
);

const DataRow = ({ label, value, border }) => (
  <tr style={{ borderBottom: border ? '1px solid #eee' : 'none' }}>
    <td style={{ padding: '8px 0', width: '110px', fontWeight: 'bold', verticalAlign: 'top', fontSize: '11pt' }}>{label}</td>
    <td style={{ padding: '8px 0', fontSize: '11pt' }}>{value || '—'}</td>
  </tr>
);

const thStyle = { padding: '8px 12px', fontSize: '9.5pt', fontWeight: 'bold', textAlign: 'center' };
const tdStyle = { padding: '8px 12px', fontSize: '9.5pt', textAlign: 'center', border: '1px solid #CCCCCC' };
const liStyle = { marginBottom: '8px', fontSize: '11pt', textAlign: 'justify', lineHeight: '1.4' };

ArmazemDocument.displayName = 'ArmazemDocument';
export default ArmazemDocument;