import React, { useState, useEffect } from 'react';
import Stepper from '../../../shared/Stepper';
import StepCliente from './StepCliente';
import StepServicos from './StepServicos';
import StepCondicoes from './StepCondicoes';
import StepRevisao from './StepRevisao';

import { fetchCatalog, saveProposal, fetchSettings } from '../../../shared/services/api';
import Button from '../../../shared/Button';
import { motion } from 'framer-motion';

import { CATALOG } from '../constants';

const STEPS = ["Cliente", "Serviços", "Condições", "Revisão"];

const ProposalWizard = () => {
  const [step, setStep] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [propNum] = useState(() => {
    const y = new Date().getFullYear();
    const m = String(new Date().getMonth() + 1).padStart(2, "0");
    const n = String(Math.floor(Math.random() * 900) + 100);
    return `${y}-${m}-${n}`;
  });

  const [cliente, setCliente] = useState({ nome: "", contato: "", cargo: "", local: "", tel: "", objeto: "" });
  const [items, setItems] = useState([]);
  const [cond, setCond] = useState({ 
    entrada: "20", 
    prazoEntrada: "45", 
    medicao: "10", 
    prazoNF: "60", 
    validade: "60", 
    prazoExec: "", 
    formaPagamento: "", 
    obs: "",
    tipoProposta: "valor_fechado" // "valor_fechado" ou "servico_continuo"
  });
  const [isDone, setIsDone] = useState(false);

  const [companySettings, setCompanySettings] = useState(null);

  useEffect(() => {
    fetchSettings()
      .then(data => {
        setCompanySettings(data);
        if (data) {
          setCond(prev => ({
            ...prev,
            entrada: data.defaultEntrada,
            prazoEntrada: data.defaultPrazoEntrada,
            medicao: data.defaultMedicao,
            prazoNF: data.defaultPrazoNF,
            validade: data.defaultValidade,
            formaPagamento: data.defaultFormaPagamento,
          }));
        }
      })
      .catch(console.error);
  }, []);

  const handleGenerate = async () => {
    // O PDF já foi gerado pelo StepRevisao — aqui apenas persiste e marca como concluído
    try {
      await saveProposal({ cliente, items, cond, propNum });
    } catch (err) {
      // Silencioso — não bloqueia o fluxo se a API estiver offline
    }
    setIsDone(true);
  };

  const reset = () => {
    setStep(0);
    setIsDone(false);
    setCliente({ nome: "", contato: "", cargo: "", local: "", tel: "", objeto: "" });
    setItems([]);
    setCond({ 
      entrada: companySettings?.defaultEntrada || "20", 
      prazoEntrada: companySettings?.defaultPrazoEntrada || "45", 
      medicao: companySettings?.defaultMedicao || "10", 
      prazoNF: companySettings?.defaultPrazoNF || "60", 
      validade: companySettings?.defaultValidade || "60", 
      prazoExec: "", 
      formaPagamento: companySettings?.defaultFormaPagamento || "", 
      obs: "",
      tipoProposta: "valor_fechado"
    });
  };

  if (isDone) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-20 space-y-8"
      >
        <div className="text-7xl mb-4">✅</div>
        <div className="space-y-3">
          <h2 className="text-3xl font-black font-syne text-white">Proposta Gerada!</h2>
          <p className="text-muted max-w-md mx-auto text-sm leading-relaxed">
            O PDF foi baixado para o seu dispositivo.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <Button variant="ghost" onClick={reset} className="px-10">
            + Nova Proposta
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center font-black text-xl">P</div>
            <div>
              <div className="font-syne font-black text-lg leading-none">Projing<span className="text-accent2">Pro</span></div>
              <div className="text-[9px] text-muted font-bold uppercase tracking-widest mt-1">SaaS de Orçamentos</div>
            </div>
          </div>
          <div className="text-[11px] font-bold text-muted bg-surface px-4 py-2 rounded-full border border-border">
            PROPOSTA: <span className="text-white ml-1">{propNum}</span>
          </div>
        </div>
        
        <Stepper current={step} steps={STEPS} />
      </div>

      <div className="min-h-[400px]">
        {step === 0 && <StepCliente data={cliente} onChange={setCliente} onNext={() => setStep(1)} />}
        {step === 1 && (
          <StepServicos 
            items={items} 
            onChange={setItems} 
            tipoProposta={cond.tipoProposta}
            onTipoChange={(val) => setCond(prev => ({ ...prev, tipoProposta: val }))}
            onNext={() => setStep(2)} 
            onBack={() => setStep(0)} 
          />
        )}
        {step === 2 && <StepCondicoes data={cond} onChange={setCond} onNext={() => setStep(3)} onBack={() => setStep(1)} />}
        {step === 3 && <StepRevisao cliente={cliente} items={items} cond={cond} propNum={propNum} companySettings={companySettings} onBack={() => setStep(2)} onGenerate={handleGenerate} />}
      </div>
    </div>
  );
};

export default ProposalWizard;
