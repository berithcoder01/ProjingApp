import React from 'react';
import Input from '../../../../shared/Input';
import { CreditCard, AlertTriangle, Calendar } from 'lucide-react';

const Step8Condicoes = ({ data, updateData }) => {
  const percentualEntrada = data.percentualEntrada || '15';
  const prazoEntrada = data.prazoEntrada || '28';
  const percentualMaterial = data.percentualMaterial || '40';
  const prazoMaterial = data.prazoMaterial || '28';
  const prazoSaldo = data.prazoSaldo || '28';

  return (
    <div className="space-y-8">
      <div className="mb-4">
        <h2 className="text-2xl font-bold font-syne text-white">Condições de Pagamento</h2>
        <p className="text-muted text-sm mt-1">
          Configure as condições de pagamento, multa contratual e validade da proposta.
        </p>
      </div>

      {/* Forma de Pagamento */}
      <div className="bg-surface border-2 border-border p-6 rounded-2xl space-y-6">
        <h3 className="font-bold text-white flex items-center gap-2">
          <CreditCard size={18} className="text-accent2" /> Forma de Pagamento
        </h3>

        <div className="bg-bg p-4 rounded-xl border border-border space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Entrada (%)
              </label>
              <input 
                type="number"
                value={percentualEntrada}
                onChange={(e) => updateData('percentualEntrada', e.target.value)}
                className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
              />
              <div className="text-xs text-muted mt-1 ml-1">Inicio (mobilização)</div>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Prazo Entrada (dias)
              </label>
              <input 
                type="number"
                value={prazoEntrada}
                onChange={(e) => updateData('prazoEntrada', e.target.value)}
                className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Entrega Material (%)
              </label>
              <input 
                type="number"
                value={percentualMaterial}
                onChange={(e) => updateData('percentualMaterial', e.target.value)}
                className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Prazo Material (dias)
              </label>
              <input 
                type="number"
                value={prazoMaterial}
                onChange={(e) => updateData('prazoMaterial', e.target.value)}
                className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Saldo após Conclusão (%)
              </label>
              <input 
                type="number"
                value={String(100 - parseFloat(percentualEntrada || 0) - parseFloat(percentualMaterial || 0))}
                readOnly
                className="w-full bg-surface border-2 border-border rounded-xl px-4 py-3 text-white font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
                Prazo Saldo (dias)
              </label>
              <input 
                type="number"
                value={prazoSaldo}
                onChange={(e) => updateData('prazoSaldo', e.target.value)}
                className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
              />
            </div>
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
            Forma de Pagamento Preferencial
          </label>
          <select 
            value={data.formaPagamento || 'depósito bancário'}
            onChange={(e) => updateData('formaPagamento', e.target.value)}
            className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
          >
            <option value="depósito bancário">Depósito bancário</option>
            <option value="transferência bancária">Transferência bancária</option>
            <option value="boleto">Boleto</option>
            <option value="PIX">PIX</option>
          </select>
        </div>
      </div>

      {/* Multa Contratual */}
      <div className="bg-surface border-2 border-border p-6 rounded-2xl space-y-4">
        <h3 className="font-bold text-white flex items-center gap-2">
          <AlertTriangle size={18} className="text-danger" /> Multa Contratual
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
              Multa por Atraso (% ao dia)
            </label>
            <input 
              type="number"
              step="0.1"
              value={data.multaDiaria || '0.3'}
              onChange={(e) => updateData('multaDiaria', e.target.value)}
              className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
              Limite da Multa (% do contrato)
            </label>
            <input 
              type="number"
              value={data.multaLimite || '10'}
              onChange={(e) => updateData('multaLimite', e.target.value)}
              className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
            />
          </div>
        </div>
      </div>

      {/* Validade e Prazo */}
      <div className="bg-surface border-2 border-border p-6 rounded-2xl space-y-4">
        <h3 className="font-bold text-white flex items-center gap-2">
          <Calendar size={18} className="text-success" /> Validade e Prazos
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
              Validade da Proposta (dias)
            </label>
            <input 
              type="number"
              value={data.validadeProposta || '60'}
              onChange={(e) => updateData('validadeProposta', e.target.value)}
              className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
              Prazo de Execução (dias por armazém)
            </label>
            <input 
              type="number"
              value={data.prazoExecucao || '45'}
              onChange={(e) => updateData('prazoExecucao', e.target.value)}
              className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent"
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-[10px] font-bold text-muted uppercase tracking-widest mb-2 ml-1">
            Observação do Prazo
          </label>
          <textarea 
            value={data.obsPrazo || 'Depende de condições climáticas e ausência de materiais no local.'}
            onChange={(e) => updateData('obsPrazo', e.target.value)}
            className="w-full bg-bg border-2 border-border rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-accent h-20 resize-none"
          />
        </div>
      </div>
    </div>
  );
};

export default Step8Condicoes;