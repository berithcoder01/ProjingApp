import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, FileText, ArrowRight, Download } from 'lucide-react';
import Button from '../../../../shared/Button';
import { saveProposal } from '../../../../shared/services/api';
import { generatePDF } from '../../services/pdfService';
import ArmazemDocument from '../ArmazemDocument';
import { useNavigate } from 'react-router-dom';
import { fmt } from '../../constants';

const Step10Documento = ({ data }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingLabel, setGeneratingLabel] = useState('Salvando...');
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const documentRef = useRef(null);
  const navigate = useNavigate();

  const handleSave = async () => {
    setIsGenerating(true);
    setGeneratingLabel('Salvando proposta...');
    setError(null);
    try {
      const payload = {
        title: `Armazém - ${data.cliente} (${data.numeroProposta})`,
        clientName: data.cliente,
        value: data.totalGeral,
        status: 'DRAFT',
        metadata: {
          tipo: 'armazem',
          numeroProposta: data.numeroProposta,
          objeto: data.objeto,
          contato: data.contato,
          local: data.local,
          referencia: data.referencia,
          geometria: data._calculo?.geometria,
          areas: data._calculo?.areas,
          material: data._calculo?.material,
          descricaoServico: data.descricaoServico,
          caracteristicasMaterial: data.caracteristicasMaterial,
          escopoResponsabilidades: data.escopoResponsabilidades,
          itensInclusos: data.itensInclusos,
          opcionais: {
            linhaVida: !!data.incluirLinhaVida,
            tubulacao: !!data.retirarTubulacao,
            faturamentoDireto: !!data.faturamentoDireto
          },
          garantias: {
            defeitos: data.garantiaDefeitos,
            acidentes: data.garantiaAcidentes,
            durabilidade: data.durabilidade,
            vistorias: data.vistorias
          },
          fornecimentoCliente: data.fornecimentoCliente,
          condicoesFaturamento: data.condicoesFaturamento,
          valores: {
            material: parseFloat(data.valorMaterialManual),
            maoDeObra: parseFloat(data.valorMaoDeObra),
            totalGeral: data.totalGeral
          },
          impostos: {
            DAS: data.impostoDAS,
            ISS: data.impostoISS,
            IPI: data.impostoIPI,
            DIFAL: data.impostoDIFAL
          },
          condicoesPagamento: {
            entrada: data.percentualEntrada,
            prazoEntrada: data.prazoEntrada,
            material: data.percentualMaterial,
            prazoMaterial: data.prazoMaterial,
            saldo: 100 - parseFloat(data.percentualEntrada || 0) - parseFloat(data.percentualMaterial || 0),
            prazoSaldo: data.prazoSaldo,
            formaPagamento: data.formaPagamento
          },
          multa: {
            diaria: data.multaDiaria,
            limite: data.multaLimite
          },
          validade: data.validadeProposta,
          prazoExecucao: data.prazoExecucao,
          obsPrazo: data.obsPrazo
        }
      };

      await saveProposal(payload);

      // Aguarda o DOM renderizar o ArmazemDocument oculto antes de capturar
      setGeneratingLabel('Gerando PDF...');
      await new Promise(resolve => setTimeout(resolve, 800));
      await generatePDF(data.numeroProposta, documentRef);

      setSuccess(true);
    } catch (e) {
      setError(e.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <>
      {/* Componente oculto para geração do PDF — opacity:0 para garantir o render para captura */}
      <div style={{ position: 'fixed', left: '-9999px', top: 0, opacity: 0, pointerEvents: 'none' }}>
        <ArmazemDocument ref={documentRef} data={data} />
      </div>

      {success ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-12 space-y-6"
        >
          <div className="w-24 h-24 bg-success/20 text-success rounded-full flex items-center justify-center mx-auto">
            <CheckCircle size={48} />
          </div>
          <h2 className="text-3xl font-black font-syne text-white">Proposta Salva!</h2>
          <p className="text-muted max-w-md mx-auto">
            Proposta salva e PDF gerado com sucesso. Verifique os downloads do seu navegador.
          </p>

          <div className="bg-surface border-2 border-border p-6 rounded-xl max-w-md mx-auto">
            <div className="text-left space-y-2">
              <div className="flex justify-between">
                <span className="text-muted">Proposta:</span>
                <span className="text-white font-bold">{data.numeroProposta}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Cliente:</span>
                <span className="text-white font-bold">{data.cliente}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Valor:</span>
                <span className="text-accent2 font-black">{fmt(data.totalGeral)}</span>
              </div>
            </div>
          </div>

          <div className="pt-8 flex justify-center gap-4">
            <Button onClick={() => navigate('/propostas')} className="px-8 py-3">
              Ir para Pipeline
            </Button>
          </div>
        </motion.div>
      ) : (
        <div className="space-y-8">
          <div className="mb-4">
            <h2 className="text-2xl font-bold font-syne text-white">Gerar Proposta</h2>
            <p className="text-muted text-sm mt-1">Confirme os dados e salve a proposta.</p>
          </div>

          <div className="bg-surface p-6 rounded-2xl border-2 border-border grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <div className="text-[10px] text-muted uppercase font-bold tracking-widest">Número da Proposta</div>
                <div className="text-white font-bold text-xl">{data.numeroProposta || '—'}</div>
              </div>
              <div>
                <div className="text-[10px] text-muted uppercase font-bold tracking-widest">Cliente / Obra</div>
                <div className="text-white font-bold">{data.cliente} - {data.local}</div>
              </div>
              <div>
                <div className="text-[10px] text-muted uppercase font-bold tracking-widest">Objeto</div>
                <div className="text-white text-sm">{data.objeto || '—'}</div>
              </div>
              <div>
                <div className="text-[10px] text-muted uppercase font-bold tracking-widest">Dimensões</div>
                <div className="text-white text-sm">
                  {data.largura}m x {data.comprimento}m | {data.espessura}mm | {(data._calculo?.areas?.totalObra || 0).toFixed(1)} m²
                </div>
              </div>
            </div>

            <div className="bg-bg p-6 rounded-xl border border-border flex flex-col justify-center items-center text-center space-y-2">
              <div className="text-[10px] text-muted uppercase font-bold tracking-widest">Valor Final</div>
              <div className="text-4xl font-black font-syne text-accent2">{fmt(data.totalGeral || 0)}</div>
              <div className="text-xs text-muted">
                Material: {fmt(parseFloat(data.valorMaterialManual) || 0)} + M.O.: {fmt(parseFloat(data.valorMaoDeObra) || 0)}
              </div>
            </div>
          </div>

          {error && <div className="text-danger font-bold text-center">{error}</div>}

          <div className="flex justify-center pt-8">
            <Button
              onClick={handleSave}
              disabled={isGenerating || !data.totalGeral}
              className="px-12 py-4 text-lg flex items-center gap-3"
            >
              {isGenerating ? generatingLabel : 'Salvar e Gerar PDF'}
              <ArrowRight size={20} />
            </Button>
          </div>

          <div className="bg-gold/10 border-2 border-gold/30 p-4 rounded-xl text-center">
            <p className="text-gold text-sm">
              📄 O PDF será gerado automaticamente após salvar.
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default Step10Documento;