import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Home, FileText, Users, Settings, LogOut } from 'lucide-react';
import { useAuth } from './context/AuthContext';

const Layout = () => {
  const { signOut, user } = useAuth();

  return (
    <div className="flex h-screen bg-bg text-text font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-surface border-r border-border/50 flex flex-col">
        <div className="p-6 border-b border-border/50 flex items-center gap-3">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center font-black text-xl text-white">P</div>
          <div>
            <div className="font-syne font-black text-lg leading-none text-white">Projing<span className="text-accent2">Pro</span></div>
            <div className="text-[9px] text-muted font-bold uppercase tracking-widest mt-1">SaaS de Orçamentos</div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${
                isActive ? 'bg-accent/10 text-accent2' : 'text-muted hover:bg-surface-hover hover:text-white'
              }`
            }
          >
            <Home size={20} />
            Dashboard
          </NavLink>
          
          <NavLink 
            to="/propostas" 
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${
                isActive ? 'bg-accent/10 text-accent2' : 'text-muted hover:bg-surface-hover hover:text-white'
              }`
            }
          >
            <FileText size={20} />
            Propostas
          </NavLink>

          <NavLink 
            to="/clientes" 
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${
                isActive ? 'bg-accent/10 text-accent2' : 'text-muted hover:bg-surface-hover hover:text-white'
              }`
            }
          >
            <Users size={20} />
            Clientes
          </NavLink>
        </nav>

        <div className="p-4 border-t border-border/50 space-y-2">
          <div className="px-4 py-2 mb-2">
            <div className="text-xs text-muted font-bold uppercase tracking-widest">Usuário</div>
            <div className="text-sm font-bold text-white truncate">{user?.name || 'Admin'}</div>
          </div>
          
          <NavLink 
            to="/configuracoes"
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all w-full text-left ${
                isActive ? 'bg-accent/10 text-accent2' : 'text-muted hover:bg-surface-hover hover:text-white'
              }`
            }
          >
            <Settings size={20} />
            Configurações
          </NavLink>
          
          <button 
            onClick={signOut}
            className="flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-danger hover:bg-danger/10 hover:text-danger transition-all w-full text-left mt-2"
          >
            <LogOut size={20} />
            Sair
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <div className="flex-1 overflow-auto p-8">
          <Outlet />
        </div>
        
        <footer className="py-4 px-8 border-t border-border/50 text-[10px] font-bold text-muted text-center uppercase tracking-[0.2em] bg-bg/95 backdrop-blur-md z-10 relative">
          Projing Pro · Soluções em PEAD · CNPJ 54.348.703/0001-34 · Marialva, PR
        </footer>
      </main>
    </div>
  );
};

export default Layout;
